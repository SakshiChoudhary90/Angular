import { Component, OnInit } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { CategoryService } from '../_services/category.service';
import { Category } from '../_models/category';
@Component({
  selector: 'app-category-edit',
  templateUrl: './category-edit.component.html',
  styleUrls: ['./category-edit.component.css'],
  providers:[CategoryService],

})
export class CategoryEditComponent implements OnInit {
  categoryForm: FormGroup;
 id:number;
  category: Category=new Category();
    constructor(private _cat:CategoryService,
      private route:ActivatedRoute,
      private router: Router,private fb:FormBuilder) {
        this.createForm();
       }
  ngOnInit() {
    this.getCategoryById();
  }
  getCategoryById(){
    this.route.params.subscribe(param=>{
      this.id=+param['id'];
      this._cat.getCategoryById(this.id).subscribe(result=>{
        this.category=result;
      })
    })
  }
  editExistingCategory(){
    this._cat.editCategory(this.id,this.category).subscribe(result=>{
      console.log('Updated successfully');
      this.router.navigate(['/category']);
    });
  }
    createForm(){
      this.categoryForm=this.fb.group({
        bookCategoryName:['',Validators.required],
        bookCategoryDescription:['',Validators.required]
      });
    
   
  }
}
