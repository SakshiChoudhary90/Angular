import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Author } from '../_models/author';


const httpOptions={
  headers: new HttpHeaders({'Content-Type' : 'application/json'})
};

@Injectable()
export class AuthorService {

  constructor(private _http: HttpClient) { }

  getAuthor(): Observable<Author[]>{
    return this._http.get<Author[]>("http://localhost:61725/api/author");
  }

  deleteAuthor(id: number): Observable<Author>{
    return this._http.delete<Author>("http://localhost:61725/api/author/" +id);
  }

  getAuthorById(id : number): Observable<Author>{
    return this._http.get<Author>("http://localhost:61725/api/author/" +id);
  }
  addAuthor(author: Author):Observable<Author>{
    return this._http.post<Author>("http://localhost:61725/api/author",author,httpOptions);
  }

  editAuthor(id: number,author: Author):Observable<Author>{
    return this._http.put<Author>("http://localhost:61725/api/author/"+id,author,httpOptions);
  }
}
