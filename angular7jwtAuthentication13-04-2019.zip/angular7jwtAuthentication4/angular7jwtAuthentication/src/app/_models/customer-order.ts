export class CustomerOrder {
   
}