import { Component, OnInit } from '@angular/core';
// import { Book } from '../models/book';
// import { BookService } from '../services/book.service';
// import { Router } from '@angular/router';
// import { Author } from '../models/author';
// import { Category } from '../models/category';
// import { Publication } from '../models/publication';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { BookService } from '../_services/book.service';
import { Book } from '../_models/book';
import { Author } from '../_models/author';
import { Category } from '../_models/category';
import { Publication } from '../_models/publication';
import { Router } from '@angular/router';

@Component({
  selector: 'app-book-add',
  templateUrl: './book-add.component.html',
  styleUrls: ['./book-add.component.css'],
  providers:[BookService]
})
export class BookAddComponent implements OnInit {
  bookForm: FormGroup;
  
  book: Book=new Book();
  authorList: Author[];
  categoryList: Category[];
  publicationList: Publication[];
  constructor(private _bk:BookService,
    private router:Router,
    private fb: FormBuilder) { 
      this.createForm();
    }

    ngOnInit() {
      this.getAllAuthors();
      this.getAllPublication();
      this.getAllCategory();
    }
    
    getAllAuthors() {
      this._bk.getAuthor().subscribe(result => {
        this.authorList = result;
        console.log(this.authorList);
      })
    }

    getAllPublication() {
      this._bk.getPublication().subscribe(result => {
        this.publicationList = result;
        console.log(this.publicationList);
      })
    }


    getAllCategory() {
      this._bk.getCategory().subscribe(result => {
        this.categoryList = result;
        console.log(this.categoryList);
      })
    }



  addNewBook(){
   this._bk.addBook(this.book).subscribe(result=>{
     console.log(result);
     console.log("book added");
     this.router.navigate(['/book']);
   })
 }

 createForm(){
  this.bookForm=this.fb.group({
    bookName:['',Validators.required],
    bookType:['',Validators.required],
    bookDescription:['',Validators.required],
    bookPrice:['',Validators.required],
    bookImage:['',Validators.required],
    authorName:['',Validators.required],
    bookCategoryName:['',Validators.required],
    publicationName:['',Validators.required]
    
  })
}

}
