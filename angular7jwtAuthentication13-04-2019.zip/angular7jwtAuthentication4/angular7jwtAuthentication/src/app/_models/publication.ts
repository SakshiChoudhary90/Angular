export class Publication {
    publicationId: number;
    publicationName:string;
    publicationDescription:string;
}