import { Component, OnInit } from '@angular/core';
import { BookService } from '../_services/book.service';
import { Book } from '../_models/book';
// import { Book } from '../models/book';
// import { BookService } from '../services/book.service';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css'],
  providers: [BookService]
})
export class BookComponent implements OnInit {

  books: Book[];
  constructor(private _bk: BookService) { }

  ngOnInit() {
    this.getAllBook();
  }
  getAllBook() {
    this._bk.getBook().subscribe(result => {
      this.books = result;
      console.log(this.books);
    });
  }
  deletingExistingBook(id:number){
    this._bk.deleteBook(id).subscribe(result=>{
     console.log("Book deleted");
      this.getAllBook();
    })

  
}
}