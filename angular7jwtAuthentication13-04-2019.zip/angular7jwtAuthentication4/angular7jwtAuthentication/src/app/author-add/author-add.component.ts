import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Author } from '../_models/author';
import { AuthorService } from '../_services/author.service';

@Component({
  selector: 'app-author-add',
  templateUrl: './author-add.component.html',
  styleUrls: ['./author-add.component.css'],
  providers:[AuthorService]
})
export class AuthorAddComponent implements OnInit {
  author: Author=new Author();
  authorForm: FormGroup;
  constructor(private _auth:AuthorService,
    private router:Router,
    private fb: FormBuilder) { 
      this.createForm();
    }

  ngOnInit() {
  }
 addNewAuthor(){
   this._auth.addAuthor(this.author).subscribe(result=>{
     console.log(result);
     console.log("Author added");
     this.router.navigate(['/author']);
   })
 }

 createForm(){
   this.authorForm=this.fb.group({
    authorName:['',Validators.required],
    authorDescription:['',Validators.required]
   })
 }

}

