import { Component, OnInit } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';
import { BookService } from '../_services/book.service';
import { Book } from '../_models/book';
import { Author } from '../_models/author';

@Component({
  selector: 'app-book-details',
  templateUrl: './book-details.component.html',
  styleUrls: ['./book-details.component.css'],
  providers:[BookService]
})
export class BookDetailsComponent implements OnInit {
  authorName:Author;
  id: number;
  book:Book= new Book();
    constructor(private route: ActivatedRoute,
      private _bk:BookService,
      private router: Router) { }
  
    ngOnInit() {
     
      this.deleteThisBook();
    }

    // getAuthorDetail(id:number){
    //   this._bk.getAuthorById(id).subscribe(result=>{
        
    //     this.authorName= result;
    //      console.log(this.authorName);
    //   })
    // }
    
    deleteThisBook(){
      this.route.params.subscribe(param=>{
        this.id= +param['id'];
        this._bk.getBookById(this.id).subscribe(result =>{
         this.book= result;
         console.log(this.book);
        });
       
      });
    }

    deletingExistingBook(id:number){
      this._bk.deleteBook(id).subscribe(result=>{
       console.log("Book deleted");
       this.router.navigate(['/book']);
      })
  
    
  }

}