import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../_services/customer.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Customer } from '../_models/customer';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-customer-edit',
  templateUrl: './customer-edit.component.html',
  styleUrls: ['./customer-edit.component.css'],
  providers:[CustomerService],
})
export class CustomerEditComponent implements OnInit {
  customerForm: FormGroup;
  id:number;
   customer: Customer=new Customer();
  constructor(private _cus:CustomerService,
    private route:ActivatedRoute,
    private router: Router,private fb:FormBuilder) {
      this.createForm();
     }

  ngOnInit() {
    this.getCustomerById();
  }
  getCustomerById(){
    this.route.params.subscribe(param=>{
      this.id=+param['id'];
      this._cus.getCustomerById(this.id).subscribe(result=>{
        this.customer=result;
      })
    })
  }
  editExistingCustomer(){
    this._cus.editCustomer(this.id,this.customer).subscribe(result=>{
      console.log('Updated successfully');
      this.router.navigate(['/customer']);
    });
  }
    createForm(){
      this.customerForm=this.fb.group({
        firstName:['',Validators.required],
        lastName:['',Validators.required],
        userName:['',Validators.required],
        email:['',Validators.required],
        country:['',Validators.required],
        state:['',Validators.required],
        billingAddress:['',Validators.required],
        zipCode:['',Validators.required],
        contact:['',Validators.required],
        shippingAddress:['',Validators.required]
     
      });
    
   
  }
}
