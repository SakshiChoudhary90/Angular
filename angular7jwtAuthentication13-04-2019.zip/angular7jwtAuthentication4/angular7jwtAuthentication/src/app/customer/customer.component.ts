import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../_services/customer.service';
import { Customer } from '../_models/customer';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css'],
  providers:[CustomerService]
})
export class CustomerComponent implements OnInit {
customers:Customer[];
  constructor( private _cus: CustomerService ) { }

  ngOnInit() {
    this.getAllCustomer();
  }
  getAllCustomer(){
    this._cus.getCustomer().subscribe(result=>{
      this.customers=result;
      console.log(this.customers);
    })
   }
  deletingExistingCustomer(id:number){
    this._cus.deleteCustomer(id).subscribe(result=>{
     console.log("Customer deleted");
      this.getAllCustomer();
    })

  
}
}
