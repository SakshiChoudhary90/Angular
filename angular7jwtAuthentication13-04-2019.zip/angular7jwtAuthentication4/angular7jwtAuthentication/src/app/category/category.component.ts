import { Component, OnInit } from '@angular/core';
import { CategoryService } from '../_services/category.service';
import { Category } from '../_models/category';
// import { CategoryService } from '../services/category.service';
// import { Category } from '../models/category';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css'],
  providers:[CategoryService]
})
export class CategoryComponent implements OnInit {
  categories: Category[];
  constructor(private _cat: CategoryService) { }

  ngOnInit() {
    this.getAllCategory();
  }
  getAllCategory(){
    this._cat.getCategory().subscribe(result=>{
      this.categories=result;
      console.log(this.categories);
    })
   }
  deletingExistingCategory(id:number){
    this._cat.deleteCategory(id).subscribe(result=>{
     console.log("Category deleted");
      this.getAllCategory();
    })

  
}
}

