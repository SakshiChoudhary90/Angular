export class Order {
        OrderId : number;
        OrderDate :Date;
        OrderAmount : number;
        CustomerId : number;
        
}
