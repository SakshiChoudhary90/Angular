import { Component, OnInit } from '@angular/core';
// import { PublicationService } from '../services/publication.service';
// import { Publication } from '../models/publication';
import{ActivatedRoute} from '@angular/router'
import{Router} from '@angular/router';
import { PublicationService } from '../_services/publication.service';
import { Publication } from '../_models/publication';

@Component({
  selector: 'app-publication-details',
  templateUrl: './publication-details.component.html',
  styleUrls: ['./publication-details.component.css'],
  providers:[PublicationService]
})
export class PublicationDetailsComponent implements OnInit {
  id: number;
  publication:Publication= new Publication();
    constructor(private route: ActivatedRoute,
      private _pub:PublicationService,
      private router: Router) { }
  
    ngOnInit() {
     
      this.deleteThisPublication();
    }

    deleteThisPublication(){
      this.route.params.subscribe(param=>{
        this.id= +param['id'];
        this._pub.getPublicationById(this.id).subscribe(result =>{
         this.publication= result;
         console.log(this.publication);
        });
       
      });
    }

    deletingExistingPublication(id:number){
      this._pub.deletePublication(id).subscribe(result=>{
       console.log("Publication deleted");
       this.router.navigate(['/publication']);
      })
  
    
  }

}
