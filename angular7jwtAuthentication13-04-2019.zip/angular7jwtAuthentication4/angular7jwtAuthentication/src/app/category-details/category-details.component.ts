import { Component, OnInit } from '@angular/core';
import { CategoryService } from '../_services/category.service';
import { Category } from '../_models/category';
import { ActivatedRoute, Router } from '@angular/router';
// import { Category } from '../models/category';
// import { ActivatedRoute, Router } from '@angular/router';
// import { CategoryService } from '../services/category.service';

@Component({
  selector: 'app-category-details',
  templateUrl: './category-details.component.html',
  styleUrls: ['./category-details.component.css'],
  providers:[CategoryService],
})
export class CategoryDetailsComponent implements OnInit {
  id: number;
  category:Category= new Category();
    constructor(private route: ActivatedRoute,
      private _cat:CategoryService,
      private router: Router) { }
  
    ngOnInit() {
     
      this.deleteThisCategory();
    }

    deleteThisCategory(){
      this.route.params.subscribe(param=>{
        this.id= +param['id'];
        this._cat.getCategoryById(this.id).subscribe(result =>{
         this.category= result;
         console.log(this.category);
        });
       
      });
    }

    deletingExistingCategory(id:number){
      this._cat.deleteCategory(id).subscribe(result=>{
       console.log("Category deleted");
       this.router.navigate(['/category']);
      })
  
    
  }
}
