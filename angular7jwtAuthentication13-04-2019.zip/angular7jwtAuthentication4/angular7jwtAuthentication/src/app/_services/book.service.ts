import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Book } from '../_models/book';
import { Author } from '../_models/author';
import { Category } from '../_models/category';
import { Publication } from '../_models/publication';


const httpOptions={
  headers: new HttpHeaders({'Content-Type' : 'application/json'})
};

@Injectable()
export class BookService {

  constructor(private _http: HttpClient) { }

  getBook(): Observable<Book[]>{
    return this._http.get<Book[]>("http://localhost:61725/api/book");
  }

  deleteBook(id: number): Observable<Book>{
    return this._http.delete<Book>("http://localhost:61725/api/book/" +id);
  }

  getBookById(id : number): Observable<Book>{
    return this._http.get<Book>("http://localhost:61725/api/book/" +id);
  }
  getAuthor(): Observable<Author[]> {
    return this._http.get<Author[]>("http://localhost:61725/api/author");
  }

  // getAuthorById(id : number): Observable<Author[]> {
  //   return this._http.get<Author[]>("http://localhost:61725/api/author/" +id);
  // }

  getCategory(): Observable<Category[]> {
    return this._http.get<Category[]>("http://localhost:61725/api/bookcategory");
  }

  getPublication(): Observable<Publication[]> {
    return this._http.get<Publication[]>("http://localhost:61725/api/publication");
  }


  addBook(book: Book):Observable<Book>{
    return this._http.post<Book>("http://localhost:61725/api/book",book,httpOptions);
  }

  editBook(id: number,book: Book):Observable<Book>{
    return this._http.put<Book>("http://localhost:61725/api/book/"+id,book,httpOptions);
  }
}
