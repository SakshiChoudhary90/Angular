export class Author {
    authorId:number;
    authorName:string;
    authorDescription:string;
}
