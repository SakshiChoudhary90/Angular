import { Component, OnInit } from '@angular/core';


import { Author } from '../_models/author';
import { AuthorService } from '../_services/author.service';

@Component({
  selector: 'app-author',
  templateUrl: './author.component.html',
  styleUrls: ['./author.component.css'],
  providers:[AuthorService]
})
export class AuthorComponent implements OnInit {
  authors: Author[];
  constructor(private _auth: AuthorService) { }

  ngOnInit() {
   this.getAllAuthor();
  }

  getAllAuthor(){
   this._auth.getAuthor().subscribe(result=>{
     this.authors=result;
     console.log(this.authors);
   })
  }

  deletingExistingAuthor(id:number){
    this._auth.deleteAuthor(id).subscribe(result=>{
     console.log("Author deleted");
      this.getAllAuthor();
    })

  
}

}
