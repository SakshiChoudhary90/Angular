import { Component, OnInit } from '@angular/core';
// import { Publication } from '../models/publication';
// import { PublicationService } from '../services/publication.service';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { PublicationService } from '../_services/publication.service';
import { Publication } from '../_models/publication';

@Component({
  selector: 'app-publication-add',
  templateUrl: './publication-add.component.html',
  styleUrls: ['./publication-add.component.css'],
  providers: [PublicationService]
})
export class PublicationAddComponent implements OnInit {
 
  publicationForm: FormGroup;

  publication: Publication = new Publication();
  constructor(private _pub: PublicationService,
    private router: Router,
    private fb:FormBuilder) { 
      this.createForm();
    }

  ngOnInit() {
  }
  addNewPublication() {
    this._pub.addPublication(this.publication).subscribe(result => {
      console.log(result);
      console.log("Publication added");
      this.router.navigate(['/publication']);
    })
  }
  createForm(){
    this.publicationForm=this.fb.group({
      publicationName:['',Validators.required],
      publicationDescription:['',Validators.required]
    });
  }

}
