import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Customer } from '../_models/customer';
import { Observable } from 'rxjs';



const httpOptions={
  headers: new HttpHeaders({'Content-Type' : 'application/json'})
};

@Injectable()
export class CustomerService {
  constructor(private _http: HttpClient) { }

  getCustomer(): Observable<Customer[]>{
    return this._http.get<Customer[]>("http://localhost:61725/api/customer");
  }

  deleteCustomer(id: number): Observable<Customer>{
    return this._http.delete<Customer>("http://localhost:61725/api/customer/" +id);
  }

  getCustomerById(id : number): Observable<Customer>{
    return this._http.get<Customer>("http://localhost:61725/api/customer/" +id);
  }
  
  addCustomer(customer: Customer):Observable<Customer>{
    return this._http.post<Customer>("http://localhost:61725/api/customer",customer,httpOptions);
  }

  editCustomer(id: number,customer: Customer):Observable<Customer>{
    return this._http.put<Customer>("http://localhost:61725/api/customer/"+id,customer,httpOptions);
  }
}

