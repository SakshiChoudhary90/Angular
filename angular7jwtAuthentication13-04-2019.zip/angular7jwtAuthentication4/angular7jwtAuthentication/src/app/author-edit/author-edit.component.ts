import { Component, OnInit } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthorService } from '../_services/author.service';
import { Author } from '../_models/author';

@Component({
  selector: 'app-author-edit',
  templateUrl: './author-edit.component.html',
  styleUrls: ['./author-edit.component.css'],
  providers:[AuthorService],
})
export class AuthorEditComponent implements OnInit {
  id:number;
  authorForm: FormGroup;
  author: Author=new Author();
    constructor(private _auth:AuthorService,
      private route:ActivatedRoute,
      private router: Router,
      private fb: FormBuilder) { 
        this.createForm();
      }
  
    ngOnInit() {
     this.getAuthorById();
    }
  
  
    getAuthorById(){
      this.route.params.subscribe(param=>{
        this.id=+param['id'];
        this._auth.getAuthorById(this.id).subscribe(result=>{
          this.author=result;
        })
      })
    }
    editExistingAuthor(){
      this._auth.editAuthor(this.id,this.author).subscribe(result=>{
        console.log('Updated successfully');
        this.router.navigate(['/author']);
      });
     
    }

    createForm(){
      this.authorForm=this.fb.group({
       authorName:['',Validators.required],
       authorDescription:['',Validators.required]
      })
    }
   
}