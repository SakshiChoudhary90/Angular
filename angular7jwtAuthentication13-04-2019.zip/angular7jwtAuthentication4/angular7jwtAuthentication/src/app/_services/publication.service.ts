import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Publication } from '../_models/publication';


const httpOptions={
  headers: new HttpHeaders({'Content-Type' : 'application/json'})
};

@Injectable({
  providedIn: 'root'
})
export class PublicationService {

  constructor(private _http: HttpClient) { }

  getPublication(): Observable<Publication[]>{
    return this._http.get<Publication[]>("http://localhost:61725/api/publication/");
  }

  deletePublication(id: number): Observable<Publication>{
    return this._http.delete<Publication>("http://localhost:61725/api/publication/" +id);
  }

  getPublicationById(id : number): Observable<Publication>{
    return this._http.get<Publication>("http://localhost:61725/api/publication/" +id);
  }
  addPublication(publication: Publication):Observable<Publication>{
    return this._http.post<Publication>("http://localhost:61725/api/publication/",publication,httpOptions);
  }

  editPublication(id: number,publication: Publication):Observable<Publication>{
    return this._http.put<Publication>("http://localhost:61725/api/publication/"+id,publication,httpOptions);
  }
}
