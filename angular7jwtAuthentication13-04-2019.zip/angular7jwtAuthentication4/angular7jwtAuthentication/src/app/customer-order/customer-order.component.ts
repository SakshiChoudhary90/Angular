import { Component, OnInit } from '@angular/core';
import { CustomerOrderService } from '../_services/customer-order.service';
import { Router, ActivatedRoute } from '@angular/router';
import { CustomerOrder } from '../_models/customer-order';
import { Order } from '../_models/order';

@Component({
  selector: 'app-customer-order',
  templateUrl: './customer-order.component.html',
  styleUrls: ['./customer-order.component.css'],
  providers:[CustomerOrderComponent]
})
export class CustomerOrderComponent implements OnInit {
id:number;
orderList: Order[];
cust_order: CustomerOrder=new CustomerOrder();
  constructor(private _cust: CustomerOrderService,
    private route:ActivatedRoute,
    ) { }

  ngOnInit() {
   this.getOrderById();
  }
getOrderById(){
  this.route.params.subscribe(param=>{
    this.id=+param['id'];
    this._cust.getCustomerById(this.id).subscribe(result=>{
      this.cust_order=result;
      
    })
  })
}
}
