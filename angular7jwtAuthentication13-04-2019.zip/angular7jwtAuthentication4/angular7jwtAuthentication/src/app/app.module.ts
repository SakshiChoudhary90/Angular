import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

// used to create fake backend
import { fakeBackendProvider } from './_helpers';

import { AppComponent } from './app.component';
import { routing } from './app.routing';

import { JwtInterceptor, ErrorInterceptor } from './_helpers';
import { HomeComponent } from './home';
import { LoginComponent } from './login';
import { AuthorComponent } from './author/author.component';
import { AuthorEditComponent } from './author-edit/author-edit.component';
import { AuthorAddComponent } from './author-add/author-add.component';
import { AuthorDetailsComponent } from './author-details/author-details.component';
import { PublicationComponent } from './publications/publications.component';
import { CategoryComponent } from './category/category.component';
import { BookComponent } from './book/book.component';
import { PublicationDetailsComponent } from './publication-details/publication-details.component';
import { PublicationAddComponent } from './publication-add/publication-add.component';
import { PublicationEditComponent } from './publication-edit/publication-edit.component';
import { CategoryAddComponent } from './category-add/category-add.component';
import { CategoryEditComponent } from './category-edit/category-edit.component';
import { CategoryDetailsComponent } from './category-details/category-details.component';
import { BookAddComponent } from './book-add/book-add.component';
import { BookDetailsComponent } from './book-details/book-details.component';
import { BookEditComponent } from './book-edit/book-edit.component';
import { CustomerComponent } from './customer/customer.component';
import { CustomerAddComponent } from './customer-add/customer-add.component';
import { CustomerEditComponent } from './customer-edit/customer-edit.component';
import { CustomerDetailsComponent } from './customer-details/customer-details.component';

import { OrderComponent } from './order/order.component';
import { CustomerOrderComponent } from './customer-order/customer-order.component';
import { OrderDetailsComponent } from './order-details/order-details.component';

@NgModule({
    imports: [
        BrowserModule,
        ReactiveFormsModule,
        HttpClientModule,
        routing,
        HttpClientModule,
        FormsModule
   
    ],
    declarations: [
        AppComponent,
        HomeComponent,
        LoginComponent,
        AuthorComponent,
        AuthorEditComponent,
        AuthorAddComponent,
        AuthorDetailsComponent,
        AuthorComponent,

        PublicationComponent,
        CategoryComponent,
        BookComponent,
        PublicationAddComponent,
        PublicationDetailsComponent,
        PublicationEditComponent,
        CategoryAddComponent,
        CategoryEditComponent,
        CategoryDetailsComponent,
        BookAddComponent,
        BookDetailsComponent,
        BookEditComponent,
        CustomerComponent,
        CustomerAddComponent,
        CustomerEditComponent,
        CustomerDetailsComponent,
        OrderComponent,
        CustomerOrderComponent,
        OrderDetailsComponent
    ],
    providers: [
        { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },

        // provider used to create fake backend
        fakeBackendProvider
    ],
    bootstrap: [AppComponent]
})

export class AppModule { }