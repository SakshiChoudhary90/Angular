import { Component, OnInit } from '@angular/core';
import { OrderService } from '../_services/order.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-order-details',
  templateUrl: './order-details.component.html',
  styleUrls: ['./order-details.component.css'],
  providers:[OrderService]
})
export class OrderDetailsComponent implements OnInit {

  constructor(private route: ActivatedRoute,
    private _or:OrderService,
    private router: Router) { }

  ngOnInit() {
    
  }

}
