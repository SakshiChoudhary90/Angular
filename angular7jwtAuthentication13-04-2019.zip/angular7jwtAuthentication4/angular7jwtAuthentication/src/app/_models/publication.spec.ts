import { Publication } from './publication';

describe('Publication', () => {
  it('should create an instance', () => {
    expect(new Publication()).toBeTruthy();
  });
});
