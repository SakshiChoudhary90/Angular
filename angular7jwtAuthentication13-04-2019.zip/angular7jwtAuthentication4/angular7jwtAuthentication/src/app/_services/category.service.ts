import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Category } from '../_models/category';


const httpOptions={
  headers: new HttpHeaders({'Content-Type' : 'application/json'})
};

@Injectable()
export class CategoryService {

  constructor(private _http: HttpClient) { }
  
  getCategory(): Observable<Category[]>{
  return this._http.get<Category[]>("http://localhost:61725/api/bookcategory");
}
deleteCategory(id: number): Observable<Category>{
  return this._http.delete<Category>("http://localhost:61725/api/bookcategory/" +id);
}

getCategoryById(id : number): Observable<Category>{
  return this._http.get<Category>("http://localhost:61725/api/bookcategory/" +id);
}
addCategory(bookcategory: Category):Observable<Category>{
  return this._http.post<Category>("http://localhost:61725/api/bookcategory/",bookcategory,httpOptions);
}

editCategory(id: number,bookcategory: Category):Observable<Category>{
  return this._http.put<Category>("http://localhost:61725/api/bookcategory/"+id,bookcategory,httpOptions);
}
}
