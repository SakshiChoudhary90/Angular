import { Component, OnInit } from '@angular/core';
import { BookService } from '../_services/book.service';
import { Author } from '../_models/author';
import { Category } from '../_models/category';
import { Publication } from '../_models/publication';
import { Book } from '../_models/book';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';


@Component({
  selector: 'app-book-edit',
  templateUrl: './book-edit.component.html',
  styleUrls: ['./book-edit.component.css'],
  providers:[BookService]
})
export class BookEditComponent implements OnInit {
  bookForm: FormGroup;
  authorList: Author[];
  categoryList: Category[];
  publicationList: Publication[];
  id:number;
  book: Book=new Book();
    constructor(private _bk:BookService,
      private route:ActivatedRoute,
      private router: Router,
      private fb: FormBuilder) { 
        this.createForm();
      }
  
    ngOnInit() {
     this.getBookById();
     this.getAllAuthors();
     this.getAllPublication();
     this.getAllCategory();
    }
    getAllAuthors() {
      this._bk.getAuthor().subscribe(result => {
        this.authorList = result;
        console.log(this.authorList);
      })
    }

    getAllPublication() {
      this._bk.getPublication().subscribe(result => {
        this.publicationList = result;
        console.log(this.publicationList);
      })
    }


    getAllCategory() {
      this._bk.getCategory().subscribe(result => {
        this.categoryList = result;
        console.log(this.categoryList);
      })
    }

  
    getBookById(){
      this.route.params.subscribe(param=>{
        this.id=+param['id'];
        this._bk.getBookById(this.id).subscribe(result=>{
          this.book=result;
        })
      })
    }
    editExistingBook(){
      this._bk.editBook(this.id,this.book).subscribe(result=>{
        console.log('Updated successfully');
        this.router.navigate(['/book']);
      });
     
    }
    createForm(){
      this.bookForm=this.fb.group({
        bookName:['',Validators.required],
        bookType:['',Validators.required],
        bookDescription:['',Validators.required],
        bookPrice:['',Validators.required],
        bookImage:['',Validators.required],
        authorName:['',Validators.required],
        bookCategoryName:['',Validators.required],
        publicationName:['',Validators.required]
        
      })

}
}
