import { Injectable } from '@angular/core';
import { HttpHeaders,HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Order } from '../_models/order';
import { Customer } from '../_models/customer';

const httpOptions={
  headers: new HttpHeaders({'Content-Type' : 'application/json'})
};
@Injectable({
  providedIn: 'root'
})
export class CustomerOrderService {

  constructor(private _http: HttpClient) { }

  getCustomerById(id : number): Observable<Customer>{
    return this._http.get<Customer>("http://localhost:61725/api/customer/" +id);
  }
}
