import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home';
import { LoginComponent } from './login';
import { AuthGuard } from './_guards';
import { AuthorComponent } from './author/author.component';
import { AuthorAddComponent } from './author-add/author-add.component';
import { AuthorEditComponent } from './author-edit/author-edit.component';
import { AuthorDetailsComponent } from './author-details/author-details.component';
import { PublicationComponent } from './publications/publications.component';
import { PublicationAddComponent } from './publication-add/publication-add.component';
import { PublicationEditComponent } from './publication-edit/publication-edit.component';
import { PublicationDetailsComponent } from './publication-details/publication-details.component';
import { CategoryDetailsComponent } from './category-details/category-details.component';
import { CategoryEditComponent } from './category-edit/category-edit.component';
import { CategoryAddComponent } from './category-add/category-add.component';
import { CategoryComponent } from './category/category.component';
import { BookComponent } from './book/book.component';
import { BookAddComponent } from './book-add/book-add.component';
import { BookEditComponent } from './book-edit/book-edit.component';
import { BookDetailsComponent } from './book-details/book-details.component';
import { CustomerComponent } from './customer/customer.component';
import { CustomerAddComponent } from './customer-add/customer-add.component';
import { CustomerEditComponent } from './customer-edit/customer-edit.component';
import { CustomerDetailsComponent } from './customer-details/customer-details.component';
import { OrderComponent } from './order/order.component';
import { CustomerOrderComponent } from './customer-order/customer-order.component';
import { OrderDetailsComponent } from './order-details/order-details.component';


const appRoutes: Routes = [
    {
        path: '',
        component: HomeComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'login',
        component: LoginComponent
    },
    {
        path: 'author-add',
        component: AuthorAddComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'author-edit/:id',
        component: AuthorEditComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'author-details/:id',
        component: AuthorDetailsComponent,
        canActivate: [AuthGuard]
    },


    {
         path: 'author', component: AuthorComponent,
    canActivate: [AuthGuard] },
    {path:'', pathMatch:'full', redirectTo:'admin'},
    
    {path : 'book', component: BookComponent ,
    canActivate: [AuthGuard] },
    {path :'book-add', component:BookAddComponent ,
    canActivate: [AuthGuard] },
    {path :'book-edit/:id', component:BookEditComponent,
    canActivate: [AuthGuard] },
    {path :'book-details/:id', component:BookDetailsComponent,
    canActivate: [AuthGuard] },

    {path :'category', component:CategoryComponent,
    canActivate: [AuthGuard] },
    {path :'category-add', component:CategoryAddComponent,
    canActivate: [AuthGuard] },
    {path :'category-edit/:id', component:CategoryEditComponent,
    canActivate: [AuthGuard] },
    {path :'category-details/:id', component:CategoryDetailsComponent,
    canActivate: [AuthGuard] },


    
    {path :'publication', component:PublicationComponent,
    canActivate: [AuthGuard] },
    {path :'publication-add', component:PublicationAddComponent,
    canActivate: [AuthGuard] },
    {path :'publication-edit/:id', component:PublicationEditComponent,
    canActivate: [AuthGuard] },
    {path :'publication-details/:id', component:PublicationDetailsComponent,
    canActivate: [AuthGuard] },


    {path :'customer', component:CustomerComponent,
    canActivate: [AuthGuard] },
    {path :'customer-add', component:CustomerAddComponent,
    canActivate: [AuthGuard] },
    {path :'customer-edit/:id', component:CustomerEditComponent,
    canActivate: [AuthGuard] },
    {path :'customer-details/:id', component:CustomerDetailsComponent,
    canActivate: [AuthGuard] },
{path:'customer-order/:id', component:CustomerOrderComponent},

    {path :'order', component:OrderComponent,
    canActivate: [AuthGuard] },
  
    

    // otherwise redirect to home
    { path: '**', redirectTo: '' }
];

export const routing = RouterModule.forRoot(appRoutes);