export class Customer {
    CustomerId: number;
    FirstName: string;
    LastName: string;
    UserName: string;
    Email: string;
    Password: string;
    Country: string;
    State: string;
    BillingAddress: string;
    ZipCode: number;
    Contact: number;
    ShippingAddress: boolean;
    SaveInformation: boolean;
    PaymentType: string;

}
