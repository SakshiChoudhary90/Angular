import { Component, OnInit } from '@angular/core';
import { Order } from '../_models/order';
import { OrderService } from '../_services/order.service';
import { CustomerService } from '../_services/customer.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ResourceLoader } from '@angular/compiler';
import { Customer } from '../_models/customer';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css'],
  providers:[OrderService,CustomerService]
})
export class OrderComponent implements OnInit {
  orders: Order[];
  order: Order=new Order();
  customer:Customer=new Customer();
  id:number;
  constructor(private _ord: OrderService,
    private _cust: CustomerService,
    private router: Router,
    private route:ActivatedRoute) { }

  ngOnInit() {
   this.getAllOrder();
   this.route.params.subscribe(param=>{
    this.id=+param['id'];
this._ord.getOrderById(this.id).subscribe(result=>{
  this.order=result;
  this._cust.getCustomerById(this.id).subscribe(res=>{
    this.customer=res;
});
    
    });

  
});
  }

  getAllOrder(){
   this._ord.getOrder().subscribe(result=>{
     this.orders=result;
     console.log(this.orders);
   })
  }
    
}
