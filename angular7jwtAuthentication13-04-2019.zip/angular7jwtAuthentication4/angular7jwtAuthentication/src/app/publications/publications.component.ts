import { Component, OnInit } from '@angular/core';
import { PublicationService } from '../_services/publication.service';
import { Publication } from '../_models/publication';
// import{ PublicationService} from '../services/publication.service';
// import { Publication } from '../models/publication';

@Component({
  selector: 'app-publication',
  templateUrl: './publications.component.html',
  styleUrls: ['./publications.component.css'],
  providers:[PublicationService]
})
export class PublicationComponent implements OnInit {

  publications: Publication[];
  constructor(private _pub: PublicationService) { }

  ngOnInit() {
   this.getAllPublication();
  }

  getAllPublication(){
    this._pub.getPublication().subscribe(result=>{
      this.publications=result;
      console.log(this.publications);
    })
  }

  deletingExistingPublication(id:number){
    this._pub.deletePublication(id).subscribe(result=>{
     console.log("Publication deleted");
      this.getAllPublication();
    })

  
}

}
