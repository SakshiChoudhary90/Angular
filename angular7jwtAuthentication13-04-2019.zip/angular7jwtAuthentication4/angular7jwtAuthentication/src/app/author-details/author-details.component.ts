import { Component, OnInit } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';
import { AuthorService } from '../_services/author.service';
import { Author } from '../_models/author';

@Component({
  selector: 'app-author-details',
  templateUrl: './author-details.component.html',
  styleUrls: ['./author-details.component.css'],
  providers:[AuthorService],
})
export class AuthorDetailsComponent implements OnInit {
  id: number;
  author:Author= new Author();
    constructor(private route: ActivatedRoute,
      private _auth:AuthorService,
      private router: Router) { }
  
    ngOnInit() {
     
      this.deleteThisAuthor();
    }

    deleteThisAuthor(){
      this.route.params.subscribe(param=>{
        this.id= +param['id'];
        this._auth.getAuthorById(this.id).subscribe(result =>{
         this.author= result;
         console.log(this.author);
        });
       
      });
    }

    deletingExistingAuthor(id:number){
      this._auth.deleteAuthor(id).subscribe(result=>{
       console.log("Author deleted");
       this.router.navigate(['/author']);
      })
  
    
  }
}
