import { Component, OnInit } from '@angular/core';
// import { CategoryService } from '../services/category.service';
// import { Category } from '../models/category';
import { Router } from '@angular/router';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { CategoryService } from '../_services/category.service';
import { Category } from '../_models/category';

@Component({
  selector: 'app-category-add',
  templateUrl: './category-add.component.html',
  styleUrls: ['./category-add.component.css'],
  providers:[CategoryService]
})
export class CategoryAddComponent implements OnInit {
  categoryForm: FormGroup;
  category: Category=new Category();
  constructor(private _cat:CategoryService,
    private router:Router,
    private fb:FormBuilder) {
      this.createForm();
     }

  ngOnInit() {
  }
  addNewCategory(){
    this._cat.addCategory(this.category).subscribe(result=>{
      console.log(result);
      console.log("Category added");
      this.router.navigate(['/category']);
    })
  }
  createForm(){
    this.categoryForm=this.fb.group({
      bookCategoryName:['',Validators.required],
      bookCategoryDescription:['',Validators.required]
    });
  }

 
}
