import { Injectable } from '@angular/core';
import { Order } from '../_models/order';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Customer } from '../_models/customer';



const httpOptions={
  headers: new HttpHeaders({'Content-Type' : 'application/json'})
};

@Injectable()
export class OrderService {

  constructor(private _http: HttpClient) { }

  getOrder(): Observable<Order[]>{
    return this._http.get<Order[]>("http://localhost:61725/api/order");
  }

  deleteOrder(id: number): Observable<Order>{
    return this._http.delete<Order>("http://localhost:61725/api/order/" +id);
  }

  getOrderById(id : number): Observable<Order>{
    return this._http.get<Order>("http://localhost:61725/api/order/" +id);
  }
  addOrder(order: Order):Observable<Order>{
    return this._http.post<Order>("http://localhost:61725/api/order",order,httpOptions);
  }

  editOrder(id: number,order: Order):Observable<Order>{
    return this._http.put<Order>("http://localhost:61725/api/order/"+id,order,httpOptions);
  }
  getCustomer(): Observable<Customer>{
    return this._http.get<Customer>("http://localhost:61725/api/customer/");
  }
}
