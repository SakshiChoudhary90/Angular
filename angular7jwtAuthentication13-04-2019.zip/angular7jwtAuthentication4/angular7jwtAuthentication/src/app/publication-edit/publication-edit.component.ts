import { Component, OnInit } from '@angular/core';
// import { Publication } from '../models/publication';
// import { PublicationService } from '../services/publication.service';
import{ActivatedRoute, Router} from '@angular/router';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { Publication } from '../_models/publication';
import { PublicationService } from '../_services/publication.service';

@Component({
  selector: 'app-publication-edit',
  templateUrl: './publication-edit.component.html',
  styleUrls: ['./publication-edit.component.css']
})
export class PublicationEditComponent implements OnInit {
  publicationForm: FormGroup;
  id:number;
  publication: Publication=new Publication();
    constructor(private _pub:PublicationService,
      private route:ActivatedRoute,
      private router: Router,
      private fb:FormBuilder) {  this.createForm(); }
  
    ngOnInit() {
     this.getPublicationById();
    }
  
  
    getPublicationById(){
      this.route.params.subscribe(param=>{
        this.id=+param['id'];
        this._pub.getPublicationById(this.id).subscribe(result=>{
          this.publication=result;
        })
      })
    }
    editExistingPublication(){
      this._pub.editPublication(this.id,this.publication).subscribe(result=>{
        console.log('Updated successfully');
        this.router.navigate(['/publication']);
      });
     
    }
    createForm(){
      this.publicationForm=this.fb.group({
        publicationName:['',Validators.required],
        publicationDescription:['',Validators.required]
      });
    }
  

}
