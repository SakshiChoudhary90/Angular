export class Book {
    
    BookId: number;
    BookName: string;
    BookType: string;
    BookDescription: string;
    BookPrice: number;
    BookImage:string;
    AuthorId: number;
    BookCategoryId: number;
    PublicationId: number;
    
}



