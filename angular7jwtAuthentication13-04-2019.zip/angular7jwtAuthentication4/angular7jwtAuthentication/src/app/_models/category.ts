export class Category {
    BookCategoryId:number;
    CategoryName:string;
    CategoryDescription:string;
}